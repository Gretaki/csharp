﻿using System;

namespace Final3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a C# program that takes a word as an input and displays it reversed
            Console.WriteLine("Test Data: ");
            String theWord = Console.ReadLine();

            //output
            Console.WriteLine("Output: ");
            for (int i = theWord.Length-1; i >=0; i--) {
                Console.Write(theWord[i]);
            }
        }
    }
}
