﻿using System;

namespace Final1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a C# program to create a new string from a given string (length 1 or more ) with the first character added at the front and back
            //test data input
            Console.WriteLine("Test Data: ");
            String testData = Console.ReadLine();

            //checking length of the input
            while (testData.Length < 1) {
                Console.WriteLine("Test Data is too short, please try again: ");
                testData = Console.ReadLine();
            }

            //output
            Console.WriteLine("Output: ");
            Console.WriteLine(testData[0] + testData + testData[0]);
        }
    }
}
