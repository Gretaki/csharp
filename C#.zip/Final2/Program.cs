﻿using System;
using System.Globalization;

namespace Final2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a program in C# Sharp to read any Month Number in integer and display Month name in the word
            //input month number
            Console.WriteLine("Test Data: ");
            int month = Int32.Parse(Console.ReadLine());

            //very big and smart calculation (it could have been just one formula)
            String monthString = "";
            switch (month){
                case 1:
                    monthString = "January";
                    break;
                case 2:
                    monthString = "February";
                    break;
                case 3:
                    monthString = "March";
                    break;
                case 4:
                    monthString = "April";
                    break;
                case 5:
                    monthString = "May";
                    break;
                case 6:
                    monthString = "June";
                    break;
                case 7:
                    monthString = "July";
                    break;
                case 8:
                    monthString = "August";
                    break;
                case 9:
                    monthString = "September";
                    break;
                case 10:
                    monthString = "October";
                    break;
                case 11:
                    monthString = "November";
                    break;
                case 12:
                    monthString = "December";
                    break;
                default:
                    monthString = "Your number is not a month number";
                    break;
            }
            //output
            Console.WriteLine("Output: ");
            Console.WriteLine(monthString);
        }
    }
}
